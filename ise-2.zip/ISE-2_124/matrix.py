import numpy as np
a=np.array([[1,2,3],[4,5,6],[7,8,9]])
b=np.array([[10,20,30],[40,50,60],[70,80,90]])
print("Addition of 3x3 matrices",a+b)
print("Subtraction of 3x3 matrices:",a-b)