def add(a,b):
    print(a+b)
def sub(a,b):
    print(a-b)
def mul(a,b):
    print (a*b)
def div(a,b):
    print (a/b)
def mod(a,b):
    print (a%b)
add(40,10)
sub(20,10)
mul(20,10)
div(30,10)
mod(30,10)