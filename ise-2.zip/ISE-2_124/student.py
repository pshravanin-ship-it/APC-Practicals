
import pandas as pd
import numpy as np
data = {
    "Roll_No": [1, 2, 3, 4, 5],
    "Name": ["Shravani", "Piyusha", "Vaishnavi", "Madhura", "Pranali"],
    "Python": [85, 72, 45, 90, 35],
    "DBMS": [80, 68, 50, 88, 40],
    "Maths": [90, 75, 42, 95, 38]
}

df = pd.DataFrame(data)


df["Total"] = df[["Python", "DBMS", "Maths"]].sum(axis=1)


df["Percentage"] = df["Total"] / 3


average = np.mean(df[["Python", "DBMS", "Maths"]].values)


def grade(per):
    if per >= 90:
        return "A+"
    elif per >= 80:
        return "A"
    elif per >= 70:
        return "B"
    elif per >= 60:
        return "C"
    elif per >= 50:
        return "D"
    else:
        return "F"

df["Grade"] = df["Percentage"].apply(grade)

def stud_class(per):
    if per >= 75:
        return "Distinction"
    elif per >= 60:
        return "First Class"
    elif per >= 50:
        return "Second Class"
    elif per >= 40:
        return "Pass "
    else:
        return "Fail"

df["Class"] = df["Percentage"].apply(stud_class)


print("STUDENT PERFORMANCE ANALYSIS")
print(df)
print("\nAverage Marks of All Students:", average)


below_pass = df[df["Percentage"] < 40]

print("\nSTUDENTS BELOW PASSING PERCENTAGE:")
print(below_pass[["Roll_No", "Name", "Total", "Percentage", "Grade", "Class"]])


