

def attendance_eligibility(attendance):
    if attendance >= 75:
        return "Eligible for examination"
    else:
        return "Not eligible for examination"