

def total_marks(marks):
    return sum(marks)


def percentage(marks):
    total = total_marks(marks)
    return total / len(marks)